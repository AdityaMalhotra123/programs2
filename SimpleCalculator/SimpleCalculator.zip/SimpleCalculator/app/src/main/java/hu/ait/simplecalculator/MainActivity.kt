package hu.ait.simplecalculator

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import hu.ait.simplecalculator.databinding.ActivityMainBinding


class MainActivity : AppCompatActivity() {
    lateinit var binding: ActivityMainBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.firstButton.setOnClickListener {
            //if (binding.etName.text.isNotEmpty()) {}

            val num1 = binding.firstNumber.text.toString().toInt()
            val num2 = binding.secondNumber.text.toString().toInt()
            val res = num1 + num2

            binding.result.text="Result: $res"

            Toast.makeText(this, "added $num1 and $num2", Toast.LENGTH_SHORT).show()


        }

        binding.secondButton.setOnClickListener {
            //if (binding.etName.text.isNotEmpty()) {}

            val num1 = binding.firstNumber.text.toString().toInt()
            val num2 = binding.secondNumber.text.toString().toInt()
            val res = num1 - num2

            binding.result.text="Result: $res"
            Toast.makeText(this, "subtracted $num2 from $num1", Toast.LENGTH_SHORT).show()



        }
    }
}

